./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_lluis.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.lluis.sx

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_henderson.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.henderson.sx 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_zhao.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.zhao.sx

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_che.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.che.sx

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_ciaramita.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.ciaramita.sx 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sx ../../eacl09/posteval/conll08_submissions/posteval_johansson.wsj.brown.closed.mrg.evalb_sx &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.johansson.sx

###

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_lluis.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.lluis.ss

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_henderson.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.henderson.ss 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_zhao.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.zhao.ss

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_che.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.che.ss

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_ciaramita.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.ciaramita.ss 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_ss ../../eacl09/posteval/conll08_submissions/posteval_johansson.wsj.brown.closed.mrg.evalb_ss &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.johansson.ss

###

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_lluis.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.lluis.sscr

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_henderson.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.henderson.sscr 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_zhao.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.zhao.sscr

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_che.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.che.sscr

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_ciaramita.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.ciaramita.sscr 

./compare-bikel.pl ../../eacl09/eacl09-results/synt-n-srl-g/test.wsj-brown.conll08.evalb_sscr ../../eacl09/posteval/conll08_submissions/posteval_johansson.wsj.brown.closed.mrg.evalb_sscr &> ../../eacl09/eacl09-results/synt-n-srl-g/statsign.johansson.sscr

